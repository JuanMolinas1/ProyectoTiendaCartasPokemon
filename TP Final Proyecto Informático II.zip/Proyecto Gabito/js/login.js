function iniciarSesion() {
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');

    const email = emailInput.value.trim().toLowerCase();
    const password = passwordInput.value.trim();

    if (!email || !password) {
        alert('Por favor, ingresa tu correo electrónico y contraseña.');
        return;
    }

    const usuariosRegistrados = JSON.parse(localStorage.getItem('usuarios')) || [];

    const usuarioEncontrado = usuariosRegistrados.find(usuario => usuario.email === email);

    if (!usuarioEncontrado) {
        alert('El correo electrónico no se encuentra registrado.');
        return;
    }

    if (usuarioEncontrado.password !== password) {
        alert('Contraseña incorrecta. Vuelve a intentarlo.');
        return;
    }

    localStorage.setItem('usuarioLogueado', JSON.stringify(usuarioEncontrado));

    alert(`¡Bienvenido de vuelta, ${usuarioEncontrado.nombre}!`);
    window.location.href = 'index.html';
}
