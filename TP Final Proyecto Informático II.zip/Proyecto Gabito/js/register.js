function registrarUsuario() {
    const nombreInput = document.getElementById('nombre');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const terminosCheckbox = document.getElementById('terminos');

    const nombre = nombreInput.value.trim();
    const email = emailInput.value.trim().toLowerCase();
    const password = passwordInput.value.trim();

    if (!nombre || !email || !password) {
        alert('Por favor, completa todos los campos.');
        return;
    }

    if (nombre.length > 25) {
        alert('El nombre no puede tener más de 25 caracteres.');
        return;
    }

    if (nombre.length < 8) {
        alert('El nombre debe tener al menos 8 caracteres.');
        return;
    }

    if (!terminosCheckbox.checked) {
        alert('Debes aceptar los términos y condiciones para registrarte.');
        return;
    }

    const usuariosRegistrados = JSON.parse(localStorage.getItem('usuarios')) || [];

    const usuarioExiste = usuariosRegistrados.some(usuario => usuario.email === email);
    if (usuarioExiste) {
        alert('Este correo electrónico ya está registrado. Intenta iniciar sesión.');
        return;
    }

    const nuevoUsuario = {
        nombre: nombre,
        email: email,
        password: password
    };

    usuariosRegistrados.push(nuevoUsuario);
    localStorage.setItem('usuarios', JSON.stringify(usuariosRegistrados));

    console.log("Usuario registrado correctamente:", nuevoUsuario);
    console.log("Lista completa de usuarios:", usuariosRegistrados);

    alert('¡Cuenta creada con éxito, Entrenador! Redirigiendo al Login...');
    
    nombreInput.value = '';
    emailInput.value = '';
    passwordInput.value = '';
    terminosCheckbox.checked = false;

    window.location.href = 'login.html';
}
