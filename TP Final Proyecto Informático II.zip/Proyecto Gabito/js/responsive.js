const btnMenu = document.getElementById('btn-menu');
    const header = document.querySelector('header');

    btnMenu.addEventListener('click', () => {
        header.classList.toggle('menu-abierto');
        const icono = btnMenu.querySelector('i');
        icono.classList.toggle('fa-bars');
        icono.classList.toggle('fa-xmark');
    });