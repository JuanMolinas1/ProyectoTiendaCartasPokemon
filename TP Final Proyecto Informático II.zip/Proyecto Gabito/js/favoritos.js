function toggearFavoritos(idProducto, categoria, esFavorito) {
    let listaFavoritos = JSON.parse(localStorage.getItem("Favoritos"));
    const producto = {id: idProducto, categoria: categoria};
    if (esFavorito) {
        listaFavoritos.unshift(producto);
    } else {
        listaFavoritos = listaFavoritos.filter(p => p.id !== idProducto);
    }
    localStorage.setItem("Favoritos", JSON.stringify(listaFavoritos));
    ordenarFavoritos();
    // console.log(`Producto con ID ${idProducto} ${esFavorito ? 'agregado' : 'eliminado'} de favoritos en la categoría ${categoria}.`);
    // console.log("Lista actualizada de favoritos:", listaFavoritos = JSON.parse(localStorage.getItem("Favoritos")));
}

function ordenarFavoritos() {
    const favoritos = JSON.parse(localStorage.getItem("Favoritos")) || [];

    const categorias = ["singles", "psa", "packs", "accesorios"];

    const ordenados = categorias.flatMap(categoria =>
        favoritos.filter(p => p.categoria === categoria)
    );

    localStorage.setItem("Favoritos", JSON.stringify(ordenados));
}

const contenedor = document.querySelector('.seccion-favoritos');

function detecFilFav() {
    const opciones = document.querySelectorAll('input[name="filtro-busqueda"]');

    opciones.forEach(opcion => {
        if (!opcion.checked) return;

        console.log("Filtro seleccionado:", opcion.id);

        contenedor.innerHTML = "";

        contenedor.classList.remove(
            'seccion-singles',
            'seccion-psa',
            'seccion-packs-accesorios'
        );

        switch (opcion.id) {
            case "opcion-singles":
                contenedor.id = "container-singles-favoritos";
                contenedor.classList.add('seccion-singles');
                mostrarSinglesFavoritos();
                break;

            case "opcion-psa":
                contenedor.id = "container-psa-favoritos";
                contenedor.classList.add('seccion-psa');
                mostrarPSAFavoritos();
                break;

            case "opcion-packs":
                contenedor.id = "container-packs-favoritos";
                contenedor.classList.add('seccion-packs-accesorios');
                mostrarPacksFavoritos();
                break;

            case "opcion-accesorios":
                contenedor.id = "container-accesorios-favoritos";
                contenedor.classList.add('seccion-packs-accesorios');
                mostrarAccesoriosFavoritos();
                break;
        }
    });
}

function configSeleccion() {
    const opciones = document.querySelectorAll('input[name="filtro-busqueda"]');

    opciones.forEach(opcion => {
        opcion.addEventListener('change', detecFilFav);
    });
}

function mostrarSinglesFavoritos() {
    const contenedor = document.querySelector('.seccion-favoritos');
    if (!contenedor) return;

    const favoritos = JSON.parse(localStorage.getItem("Favoritos")) || [];
    contenedor.innerHTML = "";

    JSON.parse(localStorage.getItem("Productos_Singles")).forEach(producto => {
        const esFavorito = favoritos.some(fav =>
            fav.id == producto.id && fav.categoria === "singles"
        );

        if (!esFavorito) return;

        let claseBotonComprar = "btn-comprar";
        let textoBotonComprar = "Añadir al carrito";

        if (producto.stock <= 0) {
            claseBotonComprar = "btn-sin-stock";
            textoBotonComprar = "Sin Stock";
        }

        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-img-container">
                <img src="${producto.img}" alt="${producto.nombre}">
            </div>
            <h4 class="arimo">${producto.nombre}<br>${producto.tipoCarta}</h4>
            <p class="arimo">Precio: $${producto.precio.toFixed(2)}</p>
            <p class="arimo">Stock: ${producto.stock}</p>
            <div class="card-buttons">
                <button class="btn-favorito activo" data-categoria="singles" data-id="${producto.id}">
                    <i class="fa-solid fa-heart"></i>
                </button>
                <!-- AGREGADO: data-stock para que el validador de límites funcione directamente -->
                <button class="${claseBotonComprar}" data-categoria="singles" data-id="${producto.id}" data-stock="${producto.stock}" ${producto.stock <= 0 ? 'disabled' : ''}>
                    <p class="arimo">${textoBotonComprar}</p>
                </button>
            </div>`;

        contenedor.appendChild(card);
    });

    configBtnComprar(contenedor);
    configBtnFav(contenedor);
}

function mostrarPSAFavoritos() {
    const contenedor = document.querySelector('.seccion-favoritos');
    if (!contenedor) return;

    const favoritos = JSON.parse(localStorage.getItem("Favoritos")) || [];
    contenedor.innerHTML = "";

    JSON.parse(localStorage.getItem("Productos_PSA")).forEach(producto => {
        const esFavorito = favoritos.some(fav =>
            fav.id == producto.id && fav.categoria === "psa"
        );

        if (!esFavorito) return;

        let claseBotonComprar = "btn-comprar";
        let textoBotonComprar = "Añadir al carrito";

        if (producto.stock <= 0) {
            claseBotonComprar = "btn-sin-stock";
            textoBotonComprar = "Sin Stock";
        }

        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-img-container">
                <img src="${producto.img}" alt="${producto.nombre}">
            </div>
            <h4 class="arimo">${producto.nombre} ${producto.tipoCarta}<br>(PSA ${producto.psa})</h4>
            <p class="arimo">Precio: $${producto.precio.toFixed(2)}</p>
            <p class="arimo">Stock: ${producto.stock}</p>
            <div class="card-buttons">
                <button class="btn-favorito activo" data-categoria="psa" data-id="${producto.id}">
                    <i class="fa-solid fa-heart"></i>
                </button>
                <button class="${claseBotonComprar}" data-categoria="psa" data-id="${producto.id}" data-stock="${producto.stock}" ${producto.stock <= 0 ? 'disabled' : ''}>
                    <p class="arimo">${textoBotonComprar}</p>
                </button>
            </div>`;

        contenedor.appendChild(card);
    });

    configBtnComprar(contenedor);
    configBtnFav(contenedor);
}

function mostrarPacksFavoritos() {
    const contenedor = document.querySelector('.seccion-favoritos');
    if (!contenedor) return;

    const favoritos = JSON.parse(localStorage.getItem("Favoritos")) || [];
    contenedor.innerHTML = "";

    JSON.parse(localStorage.getItem("Productos_Packs")).forEach(producto => {
        const esFavorito = favoritos.some(fav =>
            fav.id == producto.id && fav.categoria === "packs"
        );

        if (!esFavorito) return;

        let claseBotonComprar = "btn-comprar";
        let textoBotonComprar = "Añadir al carrito";

        if (producto.stock <= 0) {
            claseBotonComprar = "btn-sin-stock";
            textoBotonComprar = "Sin Stock";
        }

        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-img-container">
                <img src="${producto.img}" alt="${producto.nombre}">
            </div>
            <h4 class="arimo">${producto.nombre}</h4>
            <p class="arimo">Precio: $${producto.precio.toFixed(2)}</p>
            <p class="arimo">Stock: ${producto.stock}</p>
            <div class="card-buttons">
                <button class="btn-favorito activo" data-categoria="packs" data-id="${producto.id}">
                    <i class="fa-solid fa-heart"></i>
                </button>
                <button class="${claseBotonComprar}" data-categoria="packs" data-id="${producto.id}" data-stock="${producto.stock}" ${producto.stock <= 0 ? 'disabled' : ''}>
                    <p class="arimo">${textoBotonComprar}</p>
                </button>
            </div>`;

        contenedor.appendChild(card);
    });

    configBtnComprar(contenedor);
    configBtnFav(contenedor);
}

function mostrarAccesoriosFavoritos() {
    const contenedor = document.querySelector('.seccion-favoritos');
    if (!contenedor) return;

    const favoritos = JSON.parse(localStorage.getItem("Favoritos")) || [];
    contenedor.innerHTML = "";

    JSON.parse(localStorage.getItem("Productos_Accesorios")).forEach(producto => {
        const esFavorito = favoritos.some(fav =>
            fav.id == producto.id && fav.categoria === "accesorios"
        );

        if (!esFavorito) return;

        let claseBotonComprar = "btn-comprar";
        let textoBotonComprar = "Añadir al carrito";

        if (producto.stock <= 0) {
            claseBotonComprar = "btn-sin-stock";
            textoBotonComprar = "Sin Stock";
        }

        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-img-container">
                <img src="${producto.img}" alt="${producto.nombre}">
            </div>
            <h4 class="arimo">${producto.nombre}<br>(${producto.tipo})</h4>
            <p class="arimo">Precio: $${producto.precio.toFixed(2)}</p>
            <p class="arimo">Stock: ${producto.stock}</p>
            <div class="card-buttons">
                <button class="btn-favorito activo" data-categoria="accesorios" data-id="${producto.id}">
                    <i class="fa-solid fa-heart"></i>
                </button>
                <button class="${claseBotonComprar}" data-categoria="accesorios" data-id="${producto.id}" data-stock="${producto.stock}" ${producto.stock <= 0 ? 'disabled' : ''}>
                    <p class="arimo">${textoBotonComprar}</p>
                </button>
            </div>`;

        contenedor.appendChild(card);
    });

    configBtnComprar(contenedor);
    configBtnFav(contenedor);
}

configSeleccion();