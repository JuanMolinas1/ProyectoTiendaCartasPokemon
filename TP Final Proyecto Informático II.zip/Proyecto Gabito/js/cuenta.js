document.addEventListener('DOMContentLoaded', () => {
    const userText = document.getElementById('user-name-text');
    const btnLogout = document.getElementById('btn-logout');
    const userName = document.getElementById('perfil-nombre');
    const perfilEmail = document.getElementById('perfil-email');
    const usuarioGuardado = JSON.parse(localStorage.getItem('usuarioLogueado'));

    if (userName && !usuarioGuardado) {
        window.location.href = "login.html";
        return;
    }

    if (usuarioGuardado) {
        if (userText) {
            userText.textContent = `${usuarioGuardado.nombre}`;
            userText.href = "cuenta.html";
        }

        if (userName) {
            userName.textContent = `${usuarioGuardado.nombre}`;
        }

        if (perfilEmail) {
            perfilEmail.textContent = `${usuarioGuardado.email}`;
        }
    }

    if (btnLogout) {
        btnLogout.addEventListener('click', () => {
            localStorage.removeItem('usuarioLogueado');
            window.location.href = "index.html";
        });
    }
});
