function configBtnRestar(contenedor) {
    contenedor.querySelectorAll('.btn-restar').forEach(boton => {
        boton.addEventListener('click', () => {
            const idProducto = parseInt(boton.dataset.id);
            const categoria = boton.dataset.categoria;

            let carrito = JSON.parse(localStorage.getItem("Carrito")) || [];
            
            const productoEnCarrito = carrito.find(p => p.id === idProducto && p.categoria === categoria);

            if (productoEnCarrito) {
                if (productoEnCarrito.cantidad > 1) {
                    productoEnCarrito.cantidad -= 1;
                    
                    localStorage.setItem("Carrito", JSON.stringify(carrito));
                    renderizarCarrito();
                } else {
                    carrito = carrito.filter(p => !(Number(p.id) === Number(idProducto) && p.categoria === categoria));
                    localStorage.setItem("Carrito", JSON.stringify(carrito));
                    renderizarCarrito();
                }
            }
        });
    });
}

function renderizarCarrito() {
    const contenedor = document.querySelector('.tarjetas-container-carrito');
    if (!contenedor) return; 

    const carrito = JSON.parse(localStorage.getItem("Carrito")) || [];
    contenedor.innerHTML = "";

    if (carrito.length === 0) {
        contenedor.innerHTML = `<p class="arimo" id="carrito-vacio">Tu carrito está vacío...</p>`;
        actualizarTotal(0);
        return;
    }

    let totalAcumulado = 0;

    carrito.forEach(itemDelCarrito => {
        const categoriaFormateada = itemDelCarrito.categoria.charAt(0).toUpperCase() + itemDelCarrito.categoria.slice(1);
        const claveLocalStorage = `Productos_${categoriaFormateada}`;

        const baseDeDatosCategoria = JSON.parse(localStorage.getItem(claveLocalStorage)) || [];
        const productoOriginal = baseDeDatosCategoria.find(p => Number(p.id) === Number(itemDelCarrito.id));

        if (!productoOriginal) return;

        const subtotalProducto = productoOriginal.precio * itemDelCarrito.cantidad;
        totalAcumulado += subtotalProducto;

        const card = document.createElement('div');
        card.classList.add('tarjeta-producto-carrito');
        
        const detallePsa = productoOriginal.psa ? ` (PSA ${productoOriginal.psa})` : '';
        const tipoOpcional = productoOriginal.tipoCarta || productoOriginal.tipo || '';

        card.innerHTML = `
            <div class="tarjeta-nombre-cantidad">
                <h3 class="carta-nombre arimo">${productoOriginal.nombre}${detallePsa} ${tipoOpcional}</h3>
                <p class="carta-categoria arimo">| ${categoriaFormateada} |</p>
                <p class="carta-cantidad arimo">| (x${itemDelCarrito.cantidad}) |</p>
                <button class="btn-restar" data-id="${itemDelCarrito.id}" data-categoria="${itemDelCarrito.categoria}">
                    <i class="fa-solid fa-square-minus"></i>
                </button>
            </div>
            <div class="tarjeta-precio">
                <p class="carta-precio arimo">$${subtotalProducto.toFixed(2)}</p>
            </div>
        `;
            
        contenedor.appendChild(card);
    });
    configBtnRestar(contenedor);
    actualizarTotal(totalAcumulado);
    localStorage.setItem("TotalCosto", JSON.stringify(totalAcumulado));
}

function actualizarTotal(total) {
    const contenedorPrecio = document.querySelector('.precio-total');
    if (contenedorPrecio) {
        contenedorPrecio.textContent = `$${total.toFixed(2)}`;
    }
}

function limpiarCarrito() {
    const carrito = JSON.parse(localStorage.getItem("Carrito")) || [];
    if (carrito.length === 0) {
        alert("Tu carrito ya está vacío.");
        return;
    }

    localStorage.setItem("Carrito", JSON.stringify([]));
    renderizarCarrito();
}

function comprarCarrito() {
    const carrito = JSON.parse(localStorage.getItem("Carrito")) || [];
    if (carrito.length === 0) {
        alert("Tu carrito está vacío. Añade algún producto para comprar.");
        return;
    }

    restarStock();
    
    alert(`¡Gracias por tu compra en OppenPokeCards! Importe: $${localStorage.getItem("TotalCosto")}`);
    localStorage.setItem("Carrito", JSON.stringify([]));
    renderizarCarrito();
}

function restarStock() {
    const carrito = JSON.parse(localStorage.getItem("Carrito")) || [];

    carrito.forEach(itemDelCarrito => {
        const categoriaFormateada = itemDelCarrito.categoria.charAt(0).toUpperCase() + itemDelCarrito.categoria.slice(1);
        const claveLocalStorage = `Productos_${categoriaFormateada}`;

        let baseDeDatosCategoria = JSON.parse(localStorage.getItem(claveLocalStorage)) || [];

        const productoOriginal = baseDeDatosCategoria.find(p => Number(p.id) === Number(itemDelCarrito.id));

        if (productoOriginal) {
            productoOriginal.stock = Math.max(0, productoOriginal.stock - itemDelCarrito.cantidad);

            localStorage.setItem(claveLocalStorage, JSON.stringify(baseDeDatosCategoria));
        }
    });
}
renderizarCarrito();