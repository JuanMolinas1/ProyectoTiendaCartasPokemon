const productos_singles = [
    {id: 1, nombre: "Blaziken Chilling Reign", tipoCarta: "VMAX",  precio: 350.00, stock: 7,  img: "img/singles/blaziken-vmax-chilling-reign-en.jpg"}, // Precio versión Alt Art Secret
    {id: 2, nombre: "Mega Rayquaza",           tipoCarta: "EX",    precio: 75.00,  stock: 5,  img: "img/singles/mega-rayquaza-ex-en.jpg"},
    {id: 3, nombre: "Ultra Necrozma",          tipoCarta: "GX",    precio: 3.50,   stock: 10, img: "img/singles/ultra-necrozma-gx-en.jpg"},
    {id: 4, nombre: "Ursaluna Bloodmoon",      tipoCarta: "Basic", precio: 48.00,  stock: 8,  img: "img/singles/ursaluna-bloodmoon-en.jpg"},  // Precio versión Illustration Rare
    {id: 5, nombre: "Zoroark Hisui",           tipoCarta: "VSTAR", precio: 4.50,   stock: 6,  img: "img/singles/zoroark-hisui-vstar-jp.jpg"}
];

const productos_psa = [
    {id: 1, nombre: "Pikachu 25th", psa: "10", tipoCarta: "Basic", precio: 22.00,  stock: 2,  img: "img/psa/psa-10-pikachu-25th-anniversary-jp.png"},
    {id: 2, nombre: "Mega Lopunny", psa: "9",  tipoCarta: "EX",    precio: 25.00,  stock: 5,  img: "img/psa/psa-9-mega-lopunny-ex.png"},
    {id: 3, nombre: "Mewtwo",       psa: "9",  tipoCarta: "EX",    precio: 135.00, stock: 1,  img: "img/psa/psa-9-rockets-mewtwo-ex.png"},     // Precio coleccionismo vintage
    {id: 4, nombre: "Braixen",      psa: "10", tipoCarta: "Basic", precio: 38.00,  stock: 2,  img: "img/psa/psa-10-braixen-silver-tempest.png"},
    {id: 5, nombre: "Meowscarada",  psa: "10", tipoCarta: "EX",    precio: 30.00,  stock: 4,  img: "img/psa/psa-10-meowscarada-ex.png"},
    {id: 6, nombre: "Kyurem",       psa: "8",  tipoCarta: "EX",    precio: 20.00,  stock: 3,  img: "img/psa/psa-8-kyurem-ex.png"}
];

const productos_packs = [
    {id: 1, nombre: "Prismatic Evolution", precio: 7.00,  stock: 6,  img: "img/packs/pack-prismatic-evolutions.jpg"},
    {id: 2, nombre: "Scarlet Violet 151",  precio: 6.50,  stock: 9,  img: "img/packs/pack-scarlet-violet-151.jpg"},
    {id: 3, nombre: "Surging Spark",       precio: 4.25,  stock: 5,  img: "img/packs/pack-surging-sparks.jpg"},
    {id: 4, nombre: "Twilight Masquerade", precio: 4.00,  stock: 8,  img: "img/packs/pack-twilight-masquerade.jpg"},
    {id: 5, nombre: "Ultra Prism",         precio: 13.50, stock: 10, img: "img/packs/pack-ultra-prism.jpg"}            // Pack clásico descatalogado
];

const productos_accesorios = [
    {id: 1, nombre: "Dusk Mane Necrozma", tipo: "Deck Shield", precio: 14.00, stock: 8,  img: "img/accesorios/deck-shield-dusk-mane-necrozma.jpg"},
    {id: 2, nombre: "Mega Gengar",        tipo: "Deck Shield", precio: 16.50, stock: 5,  img: "img/accesorios/deck-shield-mega-gengar.jpg"},
    {id: 3, nombre: "Volcanion",          tipo: "Deck Shield", precio: 12.00, stock: 10, img: "img/accesorios/deck-shield-volcanion.jpg"},
    {id: 4, nombre: "Zygarde",            tipo: "Deck Shield", precio: 12.00, stock: 6,  img: "img/accesorios/deck-shield-zygarde.jpg"},
    {id: 5, nombre: "Pokeball",           tipo: "Playmat",     precio: 28.00, stock: 7,  img: "img/accesorios/playmat-pokeball.jpg"},
    {id: 6, nombre: "Squirtle Gang",      tipo: "Playmat",     precio: 35.00, stock: 9,  img: "img/accesorios/playmat-squirtle-gang.jpg"}
];

//localStorage.setItem("Favoritos", JSON.stringify([]));
//localStorage.setItem("Carrito", JSON.stringify([]));

// Inicializar datos en localStorage si no existen
if (localStorage.getItem("Productos_Singles") === null) {
    localStorage.setItem("Productos_Singles",    JSON.stringify(productos_singles));
}
if (localStorage.getItem("Productos_Psa") === null) {
    localStorage.setItem("Productos_Psa",        JSON.stringify(productos_psa));
}

if (localStorage.getItem("Productos_Packs") === null) {
    localStorage.setItem("Productos_Packs",      JSON.stringify(productos_packs));
}

if (localStorage.getItem("Productos_Accesorios") === null) {
    localStorage.setItem("Productos_Accesorios", JSON.stringify(productos_accesorios));
}

if (localStorage.getItem("Favoritos") === null) {
    localStorage.setItem("Favoritos", JSON.stringify([]));
}

if (localStorage.getItem("Carrito") === null) {
    localStorage.setItem("Carrito", JSON.stringify([]));
}

function configBtnComprar(contenedor) {
    contenedor.querySelectorAll('.btn-comprar').forEach(boton => {
        boton.addEventListener('click', () => {
            const idProducto = parseInt(boton.dataset.id);
            const categoria = boton.dataset.categoria;
            const stockMaximo = parseInt(boton.dataset.stock);

            let carrito = JSON.parse(localStorage.getItem("Carrito")) || [];
            
            const productoEnCarrito = carrito.find(p => p.id === idProducto && p.categoria === categoria);
            const cantidadActual = productoEnCarrito ? productoEnCarrito.cantidad : 0;

            if (cantidadActual + 1 > stockMaximo) {
                alert("Ya está el límite de stock de este producto.");
                return; 
            }

            if (productoEnCarrito) {
                productoEnCarrito.cantidad += 1;
            } else {
                carrito.unshift({ id: idProducto, categoria: categoria, cantidad: 1 });
            }

            localStorage.setItem("Carrito", JSON.stringify(carrito));
            alert("¡Producto añadido!");
            console.log(carrito);
        });
    });
}

function configBtnFav(contenedor) {
    contenedor.querySelectorAll('.btn-favorito').forEach(boton => {
        boton.addEventListener('click', () => {
            const idProducto = boton.dataset.id;
            const categoria = boton.dataset.categoria;
            const esFavorito = boton.classList.contains('activo');

            boton.classList.toggle('activo', !esFavorito);

            const icono = boton.querySelector('i');
            icono.classList.toggle('fa-solid', !esFavorito);
            icono.classList.toggle('fa-regular', esFavorito);

            toggearFavoritos(idProducto, categoria, !esFavorito);
        });
    });
}

function renderizarSingles() {
    const contenedor = document.getElementById('container-singles');
    if (!contenedor) return; 
    const favoritos = JSON.parse(localStorage.getItem("Favoritos")) || [];

    contenedor.innerHTML = "";
    JSON.parse(localStorage.getItem("Productos_Singles")).forEach(producto => {
        let claseBotonComprar = "btn-comprar";
        let textoBotonComprar = "Añadir al carrito";

        if (producto.stock <= 0) {
            claseBotonComprar = "btn-sin-stock";
            textoBotonComprar = "Sin Stock";
        }

        const esFavorito = favoritos.some(fav => fav.id == producto.id && fav.categoria === "singles");
        const iconoCorazon = esFavorito ? "fa-solid fa-heart" : "fa-regular fa-heart";
        const claseActivo = esFavorito ? "activo" : "";

        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-img-container">
                <img src="${producto.img}" alt="${producto.nombre}">
            </div>
            <h4 class="arimo">${producto.nombre}<br>${producto.tipoCarta}</h4>
            <p class="arimo">Precio: $${producto.precio.toFixed(2)}</p>
            <p class="arimo">Stock: ${producto.stock}</p>
            <div class="card-buttons">
                <button class="btn-favorito ${claseActivo}" data-categoria="singles" data-id="${producto.id}">
                    <i class="${iconoCorazon}"></i>
                </button>
                <!-- AGREGADO: data-stock para que el validador de límites funcione directamente -->
                <button class="${claseBotonComprar}" data-categoria="singles" data-id="${producto.id}" data-stock="${producto.stock}" ${producto.stock <= 0 ? 'disabled' : ''}>
                    <p class="arimo">${textoBotonComprar}</p>
                </button>
            </div>`;
            
        contenedor.appendChild(card);
    });
    configBtnComprar(contenedor);
    configBtnFav(contenedor);
}


function renderizarPsa() {
    const contenedor = document.getElementById('container-psa');
    if (!contenedor) return;

    const favoritos = JSON.parse(localStorage.getItem("Favoritos")) || [];

    contenedor.innerHTML = "";
    JSON.parse(localStorage.getItem("Productos_Psa")).forEach(producto => {
        let claseBotonComprar = "btn-comprar";
        let textoBotonComprar = "Añadir al carrito";

        if (producto.stock <= 0) {
            claseBotonComprar = "btn-sin-stock";
            textoBotonComprar = "Sin Stock";
        }

        const esFavorito = favoritos.some(fav => fav.id == producto.id && fav.categoria === "psa");
        const iconoCorazon = esFavorito ? "fa-solid fa-heart" : "fa-regular fa-heart";
        const claseActivo = esFavorito ? "activo" : "";

        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-img-container">
                <img src="${producto.img}" alt="${producto.nombre}">
            </div>
            <h4 class="arimo">${producto.nombre} ${producto.tipoCarta}<br>(PSA ${producto.psa})</h4>
            <p class="arimo">Precio: $${producto.precio.toFixed(2)}</p>
            <p class="arimo">Stock: ${producto.stock}</p>
            <div class="card-buttons">
                <button class="btn-favorito ${claseActivo}" data-categoria="psa" data-id="${producto.id}">
                    <i class="${iconoCorazon}"></i>
                </button>
                <button class="${claseBotonComprar}" data-categoria="psa" data-id="${producto.id}" data-stock="${producto.stock}" ${producto.stock <= 0 ? 'disabled' : ''}>
                    <p class="arimo">${textoBotonComprar}</p>
                </button>
            </div>`;
            
        contenedor.appendChild(card);
    });
    configBtnComprar(contenedor);
    configBtnFav(contenedor);
}

function renderizarPacks() {
    const contenedor = document.getElementById('container-packs');
    if (!contenedor) return;

    const favoritos = JSON.parse(localStorage.getItem("Favoritos")) || [];

    contenedor.innerHTML = "";
    JSON.parse(localStorage.getItem("Productos_Packs")).forEach(producto => {
        let claseBotonComprar = "btn-comprar";
        let textoBotonComprar = "Añadir al carrito";

        if (producto.stock <= 0) {
            claseBotonComprar = "btn-sin-stock";
            textoBotonComprar = "Sin Stock";
        }

        const esFavorito = favoritos.some(fav => fav.id == producto.id && fav.categoria === "packs");
        const iconoCorazon = esFavorito ? "fa-solid fa-heart" : "fa-regular fa-heart";
        const claseActivo = esFavorito ? "activo" : "";

        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-img-container">
                <img src="${producto.img}" alt="${producto.nombre}">
            </div>
            <h4 class="arimo">${producto.nombre}</h4>
            <p class="arimo">Precio: $${producto.precio.toFixed(2)}</p>
            <p class="arimo">Stock: ${producto.stock}</p>
            <div class="card-buttons">
                <button class="btn-favorito ${claseActivo}" data-categoria="packs" data-id="${producto.id}">
                    <i class="${iconoCorazon}"></i>
                </button>
                <button class="${claseBotonComprar}" data-categoria="packs" data-id="${producto.id}" data-stock="${producto.stock}" ${producto.stock <= 0 ? 'disabled' : ''}>
                    <p class="arimo">${textoBotonComprar}</p>
                </button>
            </div>`;
            
        contenedor.appendChild(card);
    });
    configBtnComprar(contenedor);
    configBtnFav(contenedor);
}


function renderizarAccesorios() {
    const contenedor = document.getElementById('container-accesorios');
    if (!contenedor) return;

    const favoritos = JSON.parse(localStorage.getItem("Favoritos")) || [];

    contenedor.innerHTML = "";
    JSON.parse(localStorage.getItem("Productos_Accesorios")).forEach(producto => {
        let claseBotonComprar = "btn-comprar";
        let textoBotonComprar = "Añadir al carrito";

        if (producto.stock <= 0) {
            claseBotonComprar = "btn-sin-stock";
            textoBotonComprar = "Sin Stock";
        }

        const esFavorito = favoritos.some(fav => fav.id == producto.id && fav.categoria === "accesorios");
        const iconoCorazon = esFavorito ? "fa-solid fa-heart" : "fa-regular fa-heart";
        const claseActivo = esFavorito ? "activo" : "";

        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-img-container">
                <img src="${producto.img}" alt="${producto.nombre}">
            </div>
            <h4 class="arimo">${producto.nombre}<br>(${producto.tipo})</h4>
            <p class="arimo">Precio: $${producto.precio.toFixed(2)}</p>
            <p class="arimo">Stock: ${producto.stock}</p>
            <div class="card-buttons">
                <button class="btn-favorito ${claseActivo}" data-categoria="accesorios" data-id="${producto.id}">
                    <i class="${iconoCorazon}"></i>
                </button>
                <button class="${claseBotonComprar}" data-categoria="accesorios" data-id="${producto.id}" data-stock="${producto.stock}" ${producto.stock <= 0 ? 'disabled' : ''}>
                    <p class="arimo">${textoBotonComprar}</p>
                </button>
            </div>`;
            
        contenedor.appendChild(card);
    });
    configBtnComprar(contenedor);
    configBtnFav(contenedor);
}

renderizarSingles();
renderizarPsa();
renderizarPacks();
renderizarAccesorios();