const productos_singles = [
    {id: 1, nombre: "Blaziken Chilling Reign", generacion: 3, tipoCarta: "VMAX",  precio: 67.00, stock: 7,  img: "img/singles/blaziken-vmax-chilling-reign-en.jpg"},
    {id: 2, nombre: "Mega Rayquaza",           generacion: 6, tipoCarta: "EX",    precio: 67.00, stock: 5,  img: "img/singles/mega-rayquaza-ex-en.jpg"},
    {id: 3, nombre: "Ultra Necrozma",          generacion: 7, tipoCarta: "GX",    precio: 67.00, stock: 10, img: "img/singles/ultra-necrozma-gx-en.jpg"},
    {id: 4, nombre: "Ursaluna Bloodmoon",      generacion: 8, tipoCarta: "Basic", precio: 67.00, stock: 8,  img: "img/singles/ursaluna-bloodmoon-en.jpg"},
    {id: 5, nombre: "Zoroark Hisui",           generacion: 8, tipoCarta: "VSTAR", precio: 67.00, stock: 6,  img: "img/singles/zoroark-hisui-vstar-jp.jpg"}
];

const productos_psa = [
    {id: 1, nombre: "Pikachu 25th", generacion: 1, psa: "10", tipoCarta: "Basic", precio: 67.00, stock: 2,  img: "img/psa/psa-10-pikachu-25th-anniversary-jp.png"},
    {id: 2, nombre: "Mega Lopunny",             generacion: 4, psa: "9",  tipoCarta: "EX",    precio: 67.00, stock: 5,  img: "img/psa/psa-9-mega-lopunny-ex.png"},
    {id: 3, nombre: "Mewtwo",                   generacion: 1, psa: "9",  tipoCarta: "EX",    precio: 67.00, stock: 1,  img: "img/psa/psa-9-rockets-mewtwo-ex.png"},
    {id: 4, nombre: "Braixen",                  generacion: 6, psa: "10", tipoCarta: "Basic", precio: 67.00, stock: 2,  img: "img/psa/psa-10-braixen-silver-tempest.png"},
    {id: 5, nombre: "Meowscarada",              generacion: 9, psa: "10", tipoCarta: "EX",    precio: 67.00, stock: 4,  img: "img/psa/psa-10-meowscarada-ex.png"},
    {id: 6, nombre: "Kyurem",                   generacion: 5, psa: "8",  tipoCarta: "EX",    precio: 67.00, stock: 3,  img: "img/psa/psa-8-kyurem-ex.png"}
];

const productos_pack = [
    {id: 1, nombre: "Prismatic Evolution", generacion: 9, precio: 67.00, stock: 6,  img: "img/packs/pack-prismatic-evolutions.jpg"},
    {id: 2, nombre: "Scarlet Violet 151",  generacion: 9, precio: 67.00, stock: 9,  img: "img/packs/pack-scarlet-violet-151.jpg"},
    {id: 3, nombre: "Surging Spark",       generacion: 9, precio: 67.00, stock: 5,  img: "img/packs/pack-surging-sparks.jpg"},
    {id: 4, nombre: "Twilight Masquerade", generacion: 6, precio: 67.00, stock: 8,  img: "img/packs/pack-twilight-masquerade.jpg"},
    {id: 5, nombre: "Ultra Prism",         generacion: 7, precio: 67.00, stock: 10, img: "img/packs/pack-ultra-prism.jpg"}
];

const productos_accesorios = [
    {id: 1, nombre: "Dusk Mane Necrozma", tipo: "Deck Shield", precio: 67.00, stock: 8,  img: "img/accesorios/deck-shield-dusk-mane-necrozma.jpg"},
    {id: 2, nombre: "Mega Gengar",        tipo: "Deck Shield", precio: 67.00, stock: 5,  img: "img/accesorios/deck-shield-mega-gengar.jpg"},
    {id: 3, nombre: "Volcanion",          tipo: "Deck Shield", precio: 67.00, stock: 10, img: "img/accesorios/deck-shield-volcanion.jpg"},
    {id: 4, nombre: "Zygarde",            tipo: "Deck Shield", precio: 67.00, stock: 6,  img: "img/accesorios/deck-shield-zygarde.jpg"},
    {id: 5, nombre: "Pokeball",           tipo: "Playmat",     precio: 67.00, stock: 7,  img: "img/accesorios/playmat-pokeball.jpg"},
    {id: 6, nombre: "Squirtle Gang",      tipo: "Playmat",     precio: 67.00, stock: 9,  img: "img/accesorios/playmat-squirtle-gang.jpg"}
];

let carrito = [];

function renderizarSingles() {
    const contenedor = document.getElementById('contenedor-singles');
    if (!contenedor) return; // Si no está en esta página, frena la función sin dar error
    
    contenedor.innerHTML = "";
    productos_singles.forEach(producto => {
        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-img-container">
                <img src="${producto.img}" alt="${producto.nombre}">
            </div>
            <h4 class="arimo">${producto.nombre}<br>${producto.tipoCarta}</h4>
            <p class="arimo">Precio: $${producto.precio.toFixed(2)}</p>
            <p class="arimo">Stock: ${producto.stock}</p>
            <div class="card-buttons">
                <button class="btn-favorito" data-categoria="singles" data-id="${producto.id}"><i class="fa-regular fa-heart"></i></button>
                <button class="boton-comprar" data-categoria="singles" data-id="${producto.id}"><p class="arimo">Añadir al carrito</p></button>
            </div>`;
        contenedor.appendChild(card);
    });
}

function renderizarPsa() {
    const contenedor = document.getElementById('contenedor-psa');
    if (!contenedor) return;

    contenedor.innerHTML = "";
    productos_psa.forEach(producto => {
        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-img-container">
                <img src="${producto.img}" alt="${producto.nombre}">
            </div>
            <h4 class="arimo">${producto.nombre}<br>(PSA ${producto.psa})</h4>
            <p class="arimo">Precio: $${producto.precio.toFixed(2)}</p>
            <p class="arimo">Stock: ${producto.stock}</p>
            <div class="card-buttons">
                <button class="btn-favorito" data-categoria="psa" data-id="${producto.id}"><i class="fa-regular fa-heart"></i></button>
                <button class="boton-comprar" data-categoria="psa" data-id="${producto.id}"><p class="arimo">Añadir al carrito</p></button>
            </div>`;
        contenedor.appendChild(card);
    });
}

function renderizarPacks() {
    const contenedor = document.getElementById('contenedor-packs');
    if (!contenedor) return;

    contenedor.innerHTML = "";
    productos_pack.forEach(producto => {
        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-img-container">
                <img src="${producto.img}" alt="${producto.nombre}">
            </div>
            <h4 class="arimo">${producto.nombre}</h4>
            <p class="arimo">Precio: $${producto.precio.toFixed(2)}</p>
            <p class="arimo">Stock: ${producto.stock}</p>
            <div class="card-buttons">
                <button class="btn-favorito" data-categoria="packs" data-id="${producto.id}"><i class="fa-regular fa-heart"></i></button>
                <button class="boton-comprar" data-categoria="packs" data-id="${producto.id}"><p class="arimo">Añadir al carrito</p></button>
            </div>`;
        contenedor.appendChild(card);
    });
}

function renderizarAccesorios() {
    const contenedor = document.getElementById('contenedor-accesorios');
    if (!contenedor) return;

    contenedor.innerHTML = "";
    productos_accesorios.forEach(producto => {
        const card = document.createElement('div');
        card.classList.add('card');
        card.innerHTML = `
            <div class="card-img-container">
                <img src="${producto.img}" alt="${producto.nombre}">
            </div>
            <h4 class="arimo">${producto.nombre}<br>(${producto.tipo})</h4>
            <p class="arimo">Precio: $${producto.precio.toFixed(2)}</p>
            <p class="arimo">Stock: ${producto.stock}</p>
            <div class="card-buttons">
                <button class="btn-favorito" data-categoria="accesorios" data-id="${producto.id}"><i class="fa-regular fa-heart"></i></button>
                <button class="boton-comprar" data-categoria="accesorios" data-id="${producto.id}"><p class="arimo">Añadir al carrito</p></button>
            </div>`;
        contenedor.appendChild(card);
    });
}

renderizarSingles();
renderizarPsa();
renderizarPacks();
renderizarAccesorios();