const productos_singles = [
    {id: 1, nombre: "Blaziken",           generacion: 3, tipoCarta: "VMAX",  precio: 67.00, img: "img/singles/blaziken-vmax-chilling-reign-en.jpg" },
    {id: 2, nombre: "Mega Rayquaza",      generacion: 6, tipoCarta: "EX",    precio: 67.00, img: "img/singles/mega-rayquaza-ex-en.jpg" },
    {id: 3, nombre: "Ultra Necrozma",     generacion: 7, tipoCarta: "GX",    precio: 67.00, img: "img/singles/ultra-necrozma-gx-en.jpg" },
    {id: 4, nombre: "Ursaluna Bloodmoon", generacion: 8, tipoCarta: "Basic", precio: 67.00, img: "img/singles/ursaluna-bloodmoon-en.jpg" },
    {id: 5, nombre: "Zoroark Hisui",      generacion: 8, tipoCarta: "VSTAR", precio: 67.00, img: "img/singles/zoroark-hisui-vstar-jp.jpg" }
];

const productos_psa = [
    {id: 1, nombre: "Pikachu 25th Anniversary", generacion: 1, psa: "10", tipoCarta: "Basic", precio: 67.00, img: "img/psa/psa-10-pikachu-25th-anniversary-jp.png" },
    {id: 2, nombre: "Mega Lopunny",             generacion: 4, psa: "9",  tipoCarta: "EX",    precio: 67.00, img: "img/psa/psa-9-mega-lopunny-ex.png" },
    {id: 3, nombre: "Mewtwo",                   generacion: 1, psa: "9",  tipoCarta: "EX",    precio: 67.00, img: "img/psa/psa-9-rockets-mewtwo-ex.png" },
    {id: 4, nombre: "Braixen",                  generacion: 6, psa: "10", tipoCarta: "Basic", precio: 67.00, img: "img/psa/psa-10-braixen-silver-tempest.png" },
    {id: 5, nombre: "Meowscarada",              generacion: 9, psa: "10", tipoCarta: "EX",    precio: 67.00, img: "img/psa/psa-10-meowscarada-silver-tempest.png" },
    {id: 6, nombre: "Kyurem",                   generacion: 5, psa: "8",  tipoCarta: "EX",    precio: 67.00, img: "img/psa/psa-10-kyurem-ex.png" }
];

const productos_pack = [
    {id: 1, nombre: "Prismatic Evolution", generacion: 9, precio: 67.00, img: "img/packs/prismatic-evolution.jpg" },
    {id: 2, nombre: "Scarlet Violet",      generacion: 9, precio: 67.00, img: "img/packs/scarlet-violet-151.jpg" },
    {id: 3, nombre: "Surging Spark",       generacion: 9, precio: 67.00, img: "img/packs/surging-spark.jpg" },
    {id: 4, nombre: "Twilight Masquerade", generacion: 6, precio: 67.00, img: "img/packs/twilight-masquerade.jpg" },
    {id: 5, nombre: "Ultra Prism",         generacion: 7, precio: 67.00, img: "img/packs/ultra-prism.jpg" },
    {id: 6, nombre: "Chaos Rising",        generacion: 6, precio: 67.00, img: "img/packs/chaos-rising.jpg" }
];

const productos_accesorios = [
    {id: 1, nombre: "Dusk Mane Necrozma", tipo: "Deck Shield", precio: 67.00, img: "img/accesorios/deck-shield-dusk-mane-necrozma.jpg" },
    {id: 2, nombre: "Mega Gengar",        tipo: "Deck Shield", precio: 67.00, img: "img/accesorios/deck-shield-mega-gengar.jpg" },
    {id: 3, nombre: "Volcanion",          tipo: "Deck Shield", precio: 67.00, img: "img/accesorios/deck-shield-volcanion.jpg" },
    {id: 4, nombre: "Zygarde",            tipo: "Deck Shield", precio: 67.00, img: "img/accesorios/deck-shield-zygarde.jpg" },
    {id: 5, nombre: "Pokeball",           tipo: "Playmat",     precio: 67.00, img: "img/accesorios/playmat-pokeball.jpg" },
    {id: 6, nombre: "Squirtle Gang",      tipo: "Playmat",     precio: 67.00, img: "img/accesorios/playmat-squirtle-gang.jpg" }
];


